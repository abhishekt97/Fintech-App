package com.app.securityapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityappApplication.class, args);
	}

}
