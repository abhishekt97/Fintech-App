package com.app.lendingengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LendingEngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
